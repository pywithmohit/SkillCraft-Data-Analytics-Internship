# Task 2 - Data Cleaning and Preparation

## Objective
Clean and prepare the Superstore dataset for analysis using Python and Pandas.

## Tools Used
- Python
- Pandas
- Jupyter Notebook

## Cleaning Steps
1. Loaded the Superstore CSV dataset.
2. Checked dataset shape, column names, and missing values.
3. Removed duplicate rows.
4. Converted date columns into proper datetime format.
5. Filled missing text values with `Unknown`.
6. Filled missing numeric values with `0`.
7. Created new columns:
   - Order Month
   - Order Year
8. Exported the final cleaned dataset.

## Files Included
- `Task2_Data_Cleaning.ipynb`
- `cleaned_superstore.csv`
- `cleaning_summary.json`

## Output
The cleaned dataset is ready for further analysis and dashboard creation.
